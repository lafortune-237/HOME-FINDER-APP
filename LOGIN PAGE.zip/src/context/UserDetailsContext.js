import {createContext} from 'react'

const UserDetailsContext = createContext()

export default UserDetailsContext